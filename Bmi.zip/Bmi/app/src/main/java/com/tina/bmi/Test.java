package com.tina.bmi;

import com.tina.bmi.hello.Person;
import com.tina.bmi.hello.Student;

public class Test {
    public static void main(String[] args) {
      /*  Student a = new Student();
      a.setId("001");
      a.setName("tina");
      a.setMath(55);
      a.setEnglish(89);
      a.print();*/
      Student b =new Student("002","jack",55,85);
    b.print();

        Student c =new Student("003","hazel",55,25);
        c.print();




        /*   Person p =new Person();
        p.hello("tina");
      p.setWeight(55);
        p.setHeight(1.5f);
        System.out.println(p.bmi());*/
    }
}
